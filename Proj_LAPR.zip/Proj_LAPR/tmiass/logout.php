<?php
    session_start();
    session_destroy();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="1.5; url=index.php"/>
<link href="style/default/css/login_logout.css" rel="stylesheet" type="text/css" />
<title>Takemore.com - Logout</title>
</head>
<body>
<div id="box">
  <div id="panel">
    <span>Saiu com Sucesso </span>
    <img src="style/default/img/logo2.png" />
    <span>Obrigado pela Visita</span>
    </div>
</div>
</body>
</html>