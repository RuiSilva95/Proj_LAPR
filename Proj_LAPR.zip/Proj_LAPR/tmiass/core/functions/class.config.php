<?php
//proteção sobre injecção no SQL
function protect($string)
{
    global $conn;
    return mysqli_real_escape_string($conn, strip_tags(addslashes($string)));
}

//Detetar pagina que utilizador está
$current_file = explode('/', $_SERVER['SCRIPT_NAME']);
$current_file = end($current_file);

//Verifica url dos componentes
function check($link)
{
    if(is_file($link)) {
        return $link;
    }else{
        return '../'.$link;
    }
}

//Acede informação do utilizador
function access($fill)
{
    global $conn;
    $login_check=mysqli_query($conn, "SELECT * FROM `users` WHERE `id_user`='".$_SESSION['id']."'");
    $get_if = mysqli_fetch_assoc($login_check);
    return $get_if[$fill];
}

//Activar forms Select quando se retorna valor
function active($valor1,$valor2)
{
    if ($valor1 == $valor2) {
          echo 'selected';
    }
}

//Pintar entity dependedo a escolha
function tint($var)
{
    switch($var){
    case 'Waits':
        echo 'bgcolor="#eff773"';
        break;
    case 'Budgeted':
        echo 'bgcolor="#1c85fb"';
        break;
    case 'Under Repair':
        echo 'bgcolor="#ffffff"';
        break;
    case 'Closed Billing':
        echo 'bgcolor="#0dfd01"';
        break;
    case 'Closed Guaranty':
        echo 'bgcolor="#08b000"';
        break;
    case 'Closed Contract':
        echo 'bgcolor="#98FF92"';
        break;
    case 'Archive':
        echo 'bgcolor="b3b3b3"';
        break;
    }
}

//Fazer calculo das horas de trabalho nas fichas
If ($_GET['code'] == "1") {
    $input1 = $_GET['input1'];
    $input2 = $_GET['input2'];

    If(!empty($input1) && !empty($input2)) {
        $horaInicial  = strtotime($input1);
        $horaFinal    = strtotime($input2);
        $totalSegundos = ($horaFinal - $horaInicial);

        $hora = sprintf("%02s", floor($totalSegundos / (60*60)));
        $totalSegundos = ($totalSegundos % (60*60));

        $minuto = sprintf("%02s", floor($totalSegundos / 60));
        $totalSegundos = ($totalSegundos % 60);

        echo $hora."H : ".$minuto." M";
    }
}
?>
