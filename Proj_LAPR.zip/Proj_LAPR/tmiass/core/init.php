<?php 
ob_start();
session_start();
error_reporting(0); 

require("database/connect.inc.php");
require("functions/class.config.php");
?>