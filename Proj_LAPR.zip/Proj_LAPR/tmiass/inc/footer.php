<div id="footer">
Copyright &copy; 2017 Direitos Reservados Rui Silva 29797 & Nuno Neto 30104 || Version 1.0
</div>
</body>
</html>
