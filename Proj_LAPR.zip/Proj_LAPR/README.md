# Proj_LAPR
Created by: Rui Silva, Nuno Neto
