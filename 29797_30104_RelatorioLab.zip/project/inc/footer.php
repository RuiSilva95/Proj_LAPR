<?php mysqli_close($conn); ?>

<!-- Jquery  CDN -->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo check('js/bootstrap.min.js'); ?>"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo check('js/plugins/morris/raphael.min.js'); ?>"></script>
<script src="<?php echo check('js/plugins/morris/morris.min.js'); ?>"></script>
<script src="<?php echo check('js/plugins/morris/morris-data.js'); ?>"></script>
<!-- Flot Charts JavaScript -->
<script src="<?php echo check('js/plugins/flot/jquery.flot.js'); ?>"></script>
<script src="<?php echo check('js/plugins/flot/jquery.flot.tooltip.min.js'); ?>"></script>
<script src="<?php echo check('js/plugins/flot/jquery.flot.resize.js'); ?>"></script>
<script src="<?php echo check('js/plugins/flot/jquery.flot.pie.js'); ?>"></script>
<script src="<?php echo check('js/plugins/flot/flot-data.js'); ?>"></script>
<script src="<?php echo check('js/ajax.js'); ?>"></script>
</body>
</html>
